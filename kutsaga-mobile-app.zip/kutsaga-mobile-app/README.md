# Kutsaga Field Operations Mobile App

A mobile-first application for field-based agricultural research, farmer engagement, and reporting.

## 🚀 Quick Start

### Fastest Way to Install on iPhone:

1. **Deploy to Vercel (Free):**
   - Go to https://vercel.com
   - Sign up for free account
   - Click "New Project"
   - Upload this entire folder
   - Get your URL (e.g., `kutsaga-field-ops.vercel.app`)

2. **Add to iPhone:**
   - Open Safari on iPhone
   - Go to your Vercel URL
   - Tap Share button (bottom)
   - Select "Add to Home Screen"
   - Tap "Add"

3. **Done!**
   - App icon appears on home screen
   - Tap to launch like a native app
   - Works offline after first load

## 💻 Local Development

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Open on iPhone (same WiFi network)
# Go to http://YOUR_IP_ADDRESS:3000
```

## 📦 Build for Production

```bash
npm run build
```

Output will be in `dist/` folder. Upload to any web host.

## 📖 Full Documentation

See `INSTALLATION_GUIDE.md` for detailed instructions including:
- Step-by-step iPhone installation
- Local testing setup
- Deployment options
- Troubleshooting
- Production recommendations

## 🎯 Features

- ✅ Log field activities with photos
- ✅ GPS and timestamp tracking
- ✅ Expense tracking per activity
- ✅ KPI progress monitoring
- ✅ Automated report generation
- ✅ Offline-first functionality
- ✅ Works as Progressive Web App

## 🔧 Tech Stack

- React 18
- Vite
- Tailwind CSS (via inline classes)
- Lucide React (icons)
- PWA Support

## 📱 Browser Support

- iOS Safari 14+ (for PWA features)
- Android Chrome 90+
- Desktop browsers (all modern)

## 🔐 Security Note

This demo version stores data locally in the browser. For production use:
- Add user authentication
- Connect to backend API
- Use HTTPS
- Implement proper data encryption

## 📞 Support

For issues or questions, refer to the troubleshooting section in `INSTALLATION_GUIDE.md`.

## 📄 License

Proprietary - Kutsaga Research Station

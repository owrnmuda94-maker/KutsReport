# Kutsaga Field Operations Mobile App
## iPhone Installation Guide

---

## 📱 OPTION 1: Install as Progressive Web App (PWA) - RECOMMENDED FOR IPHONE

This is the **easiest and fastest** method to get the app running on your iPhone without needing the App Store.

### What You Need:
- iPhone with iOS 14 or later
- Safari browser (required for PWA installation)
- Internet connection

### Step-by-Step Installation:

#### Step 1: Deploy the App Online
You need to host the app on a web server. Here are your options:

**Option A: Use Vercel (Free & Easy)**
1. Go to https://vercel.com and sign up (free account)
2. Click "Add New Project"
3. Upload the entire `kutsaga-mobile-app` folder
4. Vercel will automatically deploy it
5. You'll get a URL like: `https://kutsaga-field-ops.vercel.app`

**Option B: Use Netlify (Free & Easy)**
1. Go to https://www.netlify.com and sign up
2. Drag and drop the `dist` folder (after building - see Option 2 below)
3. Get your URL like: `https://kutsaga-field-ops.netlify.app`

**Option C: Use Your Own Server**
1. Upload the built files to your web hosting
2. Point to your domain (e.g., `https://fieldops.kutsaga.co.zw`)

#### Step 2: Open in Safari on Your iPhone
1. Open **Safari** browser (must be Safari, not Chrome)
2. Go to your deployed URL
3. The app will load in your browser

#### Step 3: Add to Home Screen
1. Tap the **Share button** (square with arrow pointing up) at the bottom
2. Scroll down and tap **"Add to Home Screen"**
3. Edit the name if you want (e.g., "Kutsaga Field Ops")
4. Tap **"Add"** in the top right

#### Step 4: Launch the App
1. Find the app icon on your iPhone home screen
2. Tap to open - it will run like a native app!
3. The app works offline after first load

### ✅ Benefits of PWA:
- ✓ No App Store approval needed
- ✓ Instant updates (just refresh)
- ✓ Works offline
- ✓ Full-screen experience
- ✓ Access to camera and GPS
- ✓ Push notifications (if enabled)
- ✓ Free to deploy
- ✓ Easy to update

---

## 💻 OPTION 2: Run Locally for Testing

If you want to test the app on your computer first, or run it on your local network:

### Requirements:
- Computer (Windows, Mac, or Linux)
- Node.js installed (download from https://nodejs.org)
- iPhone and computer on the same WiFi network

### Installation Steps:

#### Step 1: Install Node.js
1. Download from https://nodejs.org (use LTS version)
2. Install following the prompts
3. Verify installation:
   ```bash
   node --version
   npm --version
   ```

#### Step 2: Set Up the Project
1. Unzip the `kutsaga-mobile-app` folder
2. Open Terminal (Mac) or Command Prompt (Windows)
3. Navigate to the project folder:
   ```bash
   cd path/to/kutsaga-mobile-app
   ```
4. Install dependencies:
   ```bash
   npm install
   ```
   This will take 2-3 minutes

#### Step 3: Run the Development Server
1. Start the server:
   ```bash
   npm run dev
   ```
2. You'll see output like:
   ```
   VITE v4.3.9  ready in 500 ms

   ➜  Local:   http://localhost:3000/
   ➜  Network: http://192.168.1.100:3000/
   ```

#### Step 4: Access on Your iPhone
1. Make sure iPhone is on the same WiFi as your computer
2. Open Safari on your iPhone
3. Go to the Network URL (e.g., `http://192.168.1.100:3000`)
4. The app will load on your phone
5. Follow Step 3 from Option 1 to add to home screen

---

## 🚀 OPTION 3: Build for Production

If you want to deploy to your own server:

### Build the App:
```bash
cd kutsaga-mobile-app
npm install
npm run build
```

This creates a `dist` folder with optimized files.

### Deploy Options:

**1. Upload to Your Web Server:**
- Upload everything in the `dist` folder to your web hosting
- Configure your domain to point to these files
- Access via your domain

**2. Use Free Hosting:**
- **Vercel:** `npx vercel --prod`
- **Netlify:** Drag `dist` folder to netlify.com
- **Firebase:** `firebase deploy`
- **GitHub Pages:** Push to GitHub and enable Pages

---

## 📋 Quick Start Checklist

### For Fastest Setup (5 minutes):
- [ ] Create account on Vercel.com
- [ ] Upload `kutsaga-mobile-app` folder
- [ ] Get deployment URL
- [ ] Open URL in Safari on iPhone
- [ ] Tap Share → Add to Home Screen
- [ ] Launch from home screen

### For Local Testing (15 minutes):
- [ ] Install Node.js
- [ ] Extract project files
- [ ] Run `npm install`
- [ ] Run `npm run dev`
- [ ] Find Network URL
- [ ] Open on iPhone Safari
- [ ] Add to Home Screen

---

## 🔧 Troubleshooting

### "Can't connect to server"
- Make sure iPhone and computer are on same WiFi
- Check firewall isn't blocking port 3000
- Try using computer's IP address instead of localhost

### "Add to Home Screen not working"
- Must use Safari browser (not Chrome or others)
- Update iOS to latest version
- Try clearing Safari cache

### "App not working offline"
- Must open app at least once while online
- Check if Service Worker is registered (see browser console)
- For PWA, ensure HTTPS is used (except localhost)

### "Camera/GPS not working"
- Give permissions when prompted
- Check iPhone Settings → Safari → Camera/Location
- For HTTPS sites, permissions work better

---

## 🎯 Next Steps After Installation

1. **Test the app** - Log a sample activity
2. **Configure settings** - Set up your profile
3. **Train users** - Share the URL with team
4. **Customize** - Modify categories and expense types as needed
5. **Set up backend** - Connect to your database (future phase)

---

## 📞 Support

### Common Questions:

**Q: Do I need internet to use the app?**
A: After first load, the app works offline. Data syncs when online.

**Q: Can multiple people use the same app?**
A: Yes! Share the URL. Each person adds it to their home screen.

**Q: How do I update the app?**
A: Just deploy the new version. Users refresh to get updates.

**Q: Is my data secure?**
A: Currently data is stored locally. For production, add authentication and backend.

**Q: Does this work on Android too?**
A: Yes! Same process works on Android Chrome browser.

---

## 🔐 Production Recommendations

Before rolling out to all staff:

1. **Use HTTPS** - Required for camera, GPS, and security
2. **Add Authentication** - User login system
3. **Set up Database** - PostgreSQL or similar
4. **Configure Backups** - Automated daily backups
5. **Add Analytics** - Track usage and errors
6. **Test Offline Mode** - Ensure sync works properly
7. **Create User Guide** - Training materials for staff

---

## 📱 Alternative: Build Native App (Future)

For a true native app experience:

### Using React Native:
- Convert to React Native project
- Build for iOS App Store
- Requires Apple Developer Account ($99/year)
- More complex but better performance

### Using Capacitor:
- Wrap existing code with Capacitor
- Build native iOS app
- Submit to App Store
- Easier than React Native

**Current PWA approach is recommended** for faster deployment and easier updates.

---

## ✅ Summary

**Recommended Path:**
1. Deploy to Vercel (free, 5 minutes)
2. Open in Safari on iPhone
3. Add to Home Screen
4. Start using immediately

**Total Time:** 5-10 minutes
**Cost:** $0
**Maintenance:** Easy - just redeploy for updates

The app is now ready to use on your iPhone like a native app!

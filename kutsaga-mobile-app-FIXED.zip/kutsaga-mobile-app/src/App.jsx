import React, { useState, useEffect } from 'react';
import { Camera, MapPin, Calendar, Clock, DollarSign, TrendingUp, Users, FileText, Settings, Bell, ChevronRight, Plus, Upload, Check, X, Menu, ArrowLeft, BarChart3, Target, AlertCircle } from 'lucide-react';

// Mock data store
const initialActivities = [
  {
    id: '1',
    category: 'Grower Interactions',
    description: 'Visited farmer John Banda in Ward 5 to assess crop health and provide technical advice on pest management',
    date: '2026-02-07',
    time: '10:23',
    location: 'Ward 5, Harare',
    gps: { lat: -17.8252, lon: 31.0335 },
    photos: ['📷', '📷', '📷'],
    expenses: [{ type: 'Fuel', amount: 45 }],
    synced: true
  },
  {
    id: '2',
    category: 'Trials / Experiments',
    description: 'Monitoring tobacco trial plot 3A for disease resistance testing. Plants showing good response to treatment.',
    date: '2026-02-06',
    time: '14:45',
    location: 'Kutsaga Research Station',
    gps: { lat: -17.8156, lon: 31.0456 },
    photos: ['📷', '📷', '📷', '📷', '📷'],
    expenses: [],
    synced: true
  }
];

const categories = [
  'Grower Interactions',
  'Site Visits',
  'Trainings',
  'Trials / Experiments',
  'Demonstrations',
  'Meetings',
  'Administration',
  'Other'
];

const expenseTypes = [
  'Fuel',
  'Food & Accommodation',
  'Branded Items',
  'Inputs/Materials',
  'Other'
];

export default function KutsagaFieldOps() {
  const [currentScreen, setCurrentScreen] = useState('home');
  const [activities, setActivities] = useState(initialActivities);
  const [newActivity, setNewActivity] = useState({
    category: categories[0],
    description: '',
    date: new Date().toISOString().split('T')[0],
    time: new Date().toTimeString().slice(0, 5),
    location: 'Auto-detected',
    gps: { lat: -17.8252, lon: 31.0335 },
    photos: [],
    expenses: []
  });
  const [newExpense, setNewExpense] = useState({
    type: expenseTypes[0],
    amount: '',
    notes: ''
  });

  // Mock KPIs
  const kpis = [
    { name: 'Growers Engaged', current: 34, target: 50, status: 'on-track' },
    { name: 'Site Visits Conducted', current: 28, target: 40, status: 'on-track' },
    { name: 'Trainings Delivered', current: 4, target: 8, status: 'attention' },
    { name: 'Trials Established', current: 3, target: 4, status: 'on-track' }
  ];

  const weekSummary = {
    activities: 12,
    growers: 8,
    expenses: 245,
    kpiProgress: 75
  };

  // Screen: Home Dashboard
  const HomeScreen = () => (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-green-700 text-white p-4 shadow-lg">
        <div className="flex justify-between items-center mb-2">
          <h1 className="text-xl font-bold">Kutsaga Field Ops</h1>
          <div className="flex gap-3">
            <Bell className="w-6 h-6" />
            <Settings className="w-6 h-6" />
            <Users className="w-6 h-6" />
          </div>
        </div>
        <p className="text-sm opacity-90">Welcome back, John Mapfumo</p>
        <p className="text-xs opacity-75">Research Officer - Tobacco Division</p>
      </div>

      {/* Week Summary Card */}
      <div className="bg-white m-4 p-4 rounded-lg shadow">
        <h2 className="font-semibold text-gray-800 mb-3">This Week's Summary</h2>
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-blue-50 p-3 rounded">
            <div className="text-2xl font-bold text-blue-700">{weekSummary.activities}</div>
            <div className="text-xs text-gray-600">Activities logged</div>
          </div>
          <div className="bg-green-50 p-3 rounded">
            <div className="text-2xl font-bold text-green-700">{weekSummary.growers}</div>
            <div className="text-xs text-gray-600">Growers engaged</div>
          </div>
          <div className="bg-orange-50 p-3 rounded">
            <div className="text-2xl font-bold text-orange-700">${weekSummary.expenses}</div>
            <div className="text-xs text-gray-600">Expenses</div>
          </div>
          <div className="bg-purple-50 p-3 rounded">
            <div className="text-2xl font-bold text-purple-700">{weekSummary.kpiProgress}%</div>
            <div className="text-xs text-gray-600">KPI Progress</div>
          </div>
        </div>
      </div>

      {/* Primary Action Button */}
      <div className="px-4 mb-4">
        <button 
          onClick={() => setCurrentScreen('new-activity')}
          className="w-full bg-green-600 hover:bg-green-700 text-white py-4 rounded-lg font-semibold flex items-center justify-center gap-2 shadow-lg"
        >
          <Plus className="w-6 h-6" />
          LOG NEW ACTIVITY
        </button>
      </div>

      {/* Quick Actions */}
      <div className="px-4 mb-4">
        <h3 className="text-sm font-semibold text-gray-600 mb-2">Quick Actions</h3>
        <div className="grid grid-cols-2 gap-3">
          <button 
            onClick={() => setCurrentScreen('activities')}
            className="bg-white p-4 rounded-lg shadow flex flex-col items-center gap-2 hover:bg-gray-50"
          >
            <FileText className="w-8 h-8 text-blue-600" />
            <span className="text-sm font-medium">My Activities</span>
          </button>
          <button 
            onClick={() => setCurrentScreen('reports')}
            className="bg-white p-4 rounded-lg shadow flex flex-col items-center gap-2 hover:bg-gray-50"
          >
            <BarChart3 className="w-8 h-8 text-green-600" />
            <span className="text-sm font-medium">Reports</span>
          </button>
          <button className="bg-white p-4 rounded-lg shadow flex flex-col items-center gap-2 hover:bg-gray-50">
            <DollarSign className="w-8 h-8 text-orange-600" />
            <span className="text-sm font-medium">Expenses</span>
          </button>
          <button 
            onClick={() => setCurrentScreen('kpis')}
            className="bg-white p-4 rounded-lg shadow flex flex-col items-center gap-2 hover:bg-gray-50"
          >
            <Target className="w-8 h-8 text-purple-600" />
            <span className="text-sm font-medium">KPIs</span>
          </button>
        </div>
      </div>

      {/* Recent Activities */}
      <div className="px-4 pb-4">
        <h3 className="text-sm font-semibold text-gray-600 mb-2">Recent Activities</h3>
        {activities.slice(0, 3).map(activity => (
          <div key={activity.id} className="bg-white p-4 rounded-lg shadow mb-2 hover:bg-gray-50">
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <Camera className="w-4 h-4 text-gray-500" />
                  <span className="font-semibold text-sm">{activity.category}</span>
                </div>
                <p className="text-xs text-gray-600 mb-1">{activity.description.slice(0, 60)}...</p>
                <div className="flex items-center gap-3 text-xs text-gray-500">
                  <span>{activity.date === '2026-02-07' ? 'Today' : 'Yesterday'}, {activity.time}</span>
                  <span>{activity.photos.length} photos</span>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  // Screen: Log New Activity
  const NewActivityScreen = () => (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-green-700 text-white p-4 shadow-lg flex justify-between items-center">
        <div className="flex items-center gap-3">
          <ArrowLeft className="w-6 h-6 cursor-pointer" onClick={() => setCurrentScreen('home')} />
          <h1 className="text-xl font-bold">Log New Activity</h1>
        </div>
        <Check className="w-6 h-6 cursor-pointer" onClick={handleSaveActivity} />
      </div>

      <div className="p-4 space-y-4">
        {/* Category Selection */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            Activity Category <span className="text-red-500">*</span>
          </label>
          <select 
            value={newActivity.category}
            onChange={(e) => setNewActivity({...newActivity, category: e.target.value})}
            className="w-full p-3 border border-gray-300 rounded-lg bg-white"
          >
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>

        {/* Photos */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">Photos</label>
          <div className="flex gap-3 mb-3">
            {newActivity.photos.map((photo, idx) => (
              <div key={idx} className="w-20 h-20 bg-gray-200 rounded flex items-center justify-center text-3xl">
                📷
              </div>
            ))}
            <div 
              className="w-20 h-20 border-2 border-dashed border-gray-300 rounded flex items-center justify-center cursor-pointer hover:bg-gray-50"
              onClick={() => setNewActivity({...newActivity, photos: [...newActivity.photos, '📷']})}
            >
              <Plus className="w-8 h-8 text-gray-400" />
            </div>
          </div>
          <div className="flex gap-2">
            <button 
              onClick={() => setNewActivity({...newActivity, photos: [...newActivity.photos, '📷']})}
              className="flex-1 bg-blue-600 text-white py-2 px-4 rounded flex items-center justify-center gap-2"
            >
              <Camera className="w-5 h-5" />
              Camera
            </button>
            <button 
              onClick={() => setNewActivity({...newActivity, photos: [...newActivity.photos, '📷']})}
              className="flex-1 bg-gray-600 text-white py-2 px-4 rounded flex items-center justify-center gap-2"
            >
              <Upload className="w-5 h-5" />
              Gallery
            </button>
          </div>
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            Description <span className="text-red-500">*</span>
          </label>
          <textarea
            value={newActivity.description}
            onChange={(e) => setNewActivity({...newActivity, description: e.target.value})}
            placeholder="Describe the activity in detail..."
            className="w-full p-3 border border-gray-300 rounded-lg h-32"
          />
        </div>

        {/* Location */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">Location</label>
          <div className="bg-blue-50 p-3 rounded-lg">
            <div className="flex items-center gap-2 mb-1">
              <MapPin className="w-5 h-5 text-blue-600" />
              <span className="text-sm font-medium">Auto: {newActivity.gps.lat}, {newActivity.gps.lon}</span>
            </div>
            <p className="text-xs text-gray-600">{newActivity.location}</p>
          </div>
          <div className="flex gap-2 mt-2">
            <button className="flex-1 bg-blue-100 text-blue-700 py-2 px-4 rounded text-sm font-medium">
              Use Current
            </button>
            <button className="flex-1 bg-gray-100 text-gray-700 py-2 px-4 rounded text-sm font-medium">
              Edit
            </button>
          </div>
        </div>

        {/* Date & Time */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Date</label>
            <div className="flex items-center gap-2 p-3 border border-gray-300 rounded-lg bg-white">
              <Calendar className="w-5 h-5 text-gray-500" />
              <input 
                type="date" 
                value={newActivity.date}
                onChange={(e) => setNewActivity({...newActivity, date: e.target.value})}
                className="flex-1 outline-none"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Time</label>
            <div className="flex items-center gap-2 p-3 border border-gray-300 rounded-lg bg-white">
              <Clock className="w-5 h-5 text-gray-500" />
              <input 
                type="time" 
                value={newActivity.time}
                onChange={(e) => setNewActivity({...newActivity, time: e.target.value})}
                className="flex-1 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Add Expenses */}
        <button 
          onClick={() => setCurrentScreen('add-expense')}
          className="w-full border-2 border-dashed border-green-300 text-green-700 py-3 rounded-lg font-medium hover:bg-green-50"
        >
          + Add Expenses to Activity
        </button>

        {/* Expenses List */}
        {newActivity.expenses.length > 0 && (
          <div className="bg-gray-50 p-3 rounded-lg">
            <h3 className="text-sm font-semibold text-gray-700 mb-2">Expenses Added</h3>
            {newActivity.expenses.map((exp, idx) => (
              <div key={idx} className="flex justify-between items-center py-2 border-b border-gray-200 last:border-0">
                <div>
                  <span className="text-sm font-medium">{exp.type}</span>
                  {exp.notes && <p className="text-xs text-gray-500">{exp.notes}</p>}
                </div>
                <span className="font-semibold">${exp.amount}</span>
              </div>
            ))}
            <div className="mt-2 pt-2 border-t border-gray-300 flex justify-between">
              <span className="font-semibold">Total</span>
              <span className="font-bold text-green-700">
                ${newActivity.expenses.reduce((sum, exp) => sum + parseFloat(exp.amount), 0).toFixed(2)}
              </span>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex gap-3 pt-4">
          <button className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg font-semibold">
            Save as Draft
          </button>
          <button 
            onClick={handleSaveActivity}
            className="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold"
          >
            Submit Activity
          </button>
        </div>
      </div>
    </div>
  );

  // Screen: Add Expense
  const AddExpenseScreen = () => (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-green-700 text-white p-4 shadow-lg flex justify-between items-center">
        <div className="flex items-center gap-3">
          <ArrowLeft className="w-6 h-6 cursor-pointer" onClick={() => setCurrentScreen('new-activity')} />
          <h1 className="text-xl font-bold">Add Expense</h1>
        </div>
        <Check className="w-6 h-6 cursor-pointer" onClick={handleAddExpense} />
      </div>

      <div className="p-4 space-y-4">
        <div className="bg-blue-50 p-3 rounded-lg text-sm">
          <span className="font-medium">Linked to:</span> {newActivity.category}
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            Expense Type <span className="text-red-500">*</span>
          </label>
          <select 
            value={newExpense.type}
            onChange={(e) => setNewExpense({...newExpense, type: e.target.value})}
            className="w-full p-3 border border-gray-300 rounded-lg bg-white"
          >
            {expenseTypes.map(type => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            Amount (USD) <span className="text-red-500">*</span>
          </label>
          <div className="flex items-center gap-2 p-3 border border-gray-300 rounded-lg bg-white">
            <DollarSign className="w-5 h-5 text-gray-500" />
            <input 
              type="number" 
              value={newExpense.amount}
              onChange={(e) => setNewExpense({...newExpense, amount: e.target.value})}
              placeholder="0.00"
              className="flex-1 outline-none"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">Receipt</label>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center bg-white">
            <Upload className="w-12 h-12 text-gray-400 mx-auto mb-2" />
            <p className="text-sm text-gray-500 mb-3">No receipt uploaded</p>
            <div className="flex gap-2">
              <button className="flex-1 bg-blue-600 text-white py-2 px-4 rounded flex items-center justify-center gap-2">
                <Camera className="w-5 h-5" />
                Scan Receipt
              </button>
              <button className="flex-1 bg-gray-600 text-white py-2 px-4 rounded flex items-center justify-center gap-2">
                <Upload className="w-5 h-5" />
                Upload
              </button>
            </div>
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">Notes</label>
          <textarea
            value={newExpense.notes}
            onChange={(e) => setNewExpense({...newExpense, notes: e.target.value})}
            placeholder="Additional notes about this expense..."
            className="w-full p-3 border border-gray-300 rounded-lg h-24"
          />
        </div>

        <button 
          onClick={handleAddExpense}
          className="w-full bg-green-600 text-white py-3 rounded-lg font-semibold"
        >
          Add Expense
        </button>
      </div>
    </div>
  );

  // Screen: Activities List
  const ActivitiesScreen = () => (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-green-700 text-white p-4 shadow-lg">
        <div className="flex items-center gap-3 mb-3">
          <ArrowLeft className="w-6 h-6 cursor-pointer" onClick={() => setCurrentScreen('home')} />
          <h1 className="text-xl font-bold">My Activities</h1>
        </div>
        <div className="flex gap-2">
          <select className="flex-1 p-2 rounded bg-white text-gray-800 text-sm">
            <option>This Week</option>
            <option>This Month</option>
            <option>Last Month</option>
            <option>Custom Range</option>
          </select>
          <select className="flex-1 p-2 rounded bg-white text-gray-800 text-sm">
            <option>All Types</option>
            {categories.map(cat => (
              <option key={cat}>{cat}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="p-4 space-y-3">
        {activities.map(activity => (
          <div key={activity.id} className="bg-white p-4 rounded-lg shadow">
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center gap-2">
                <Camera className="w-5 h-5 text-blue-600" />
                <span className="font-semibold text-sm">{activity.category}</span>
              </div>
              {activity.synced ? (
                <div className="flex items-center gap-1 text-green-600 text-xs">
                  <Check className="w-4 h-4" />
                  Synced
                </div>
              ) : (
                <div className="flex items-center gap-1 text-orange-600 text-xs">
                  <Clock className="w-4 h-4" />
                  Pending sync
                </div>
              )}
            </div>
            <p className="text-sm text-gray-700 mb-2">{activity.description}</p>
            <div className="flex items-center gap-4 text-xs text-gray-500 mb-2">
              <span>{activity.date === '2026-02-07' ? 'Today' : activity.date}, {activity.time}</span>
              <span>{activity.photos.length} photos</span>
              {activity.expenses.length > 0 && (
                <span>${activity.expenses.reduce((sum, exp) => sum + exp.amount, 0)} expenses</span>
              )}
            </div>
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <MapPin className="w-3 h-3" />
              <span>{activity.location}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  // Screen: KPI Dashboard
  const KPIScreen = () => (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-green-700 text-white p-4 shadow-lg">
        <div className="flex items-center gap-3 mb-2">
          <ArrowLeft className="w-6 h-6 cursor-pointer" onClick={() => setCurrentScreen('home')} />
          <h1 className="text-xl font-bold">My KPI Progress</h1>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm opacity-90">Q1 2026</span>
          <select className="bg-white text-gray-800 text-sm p-1 rounded">
            <option>Q1 2026</option>
            <option>Q2 2026</option>
          </select>
        </div>
      </div>

      <div className="p-4">
        {/* Overall Progress */}
        <div className="bg-white p-4 rounded-lg shadow mb-4">
          <div className="flex justify-between items-center mb-2">
            <h2 className="font-semibold">Overall Progress</h2>
            <span className="text-2xl font-bold text-green-700">68%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div className="bg-green-600 h-3 rounded-full" style={{width: '68%'}}></div>
          </div>
        </div>

        {/* Individual KPIs */}
        <div className="space-y-3">
          {kpis.map((kpi, idx) => {
            const percentage = (kpi.current / kpi.target) * 100;
            const statusColor = kpi.status === 'on-track' ? 'green' : 'orange';
            const statusText = kpi.status === 'on-track' ? 'On Track' : 'Needs Attention';
            
            return (
              <div key={idx} className="bg-white p-4 rounded-lg shadow">
                <h3 className="font-semibold text-gray-800 mb-2">{kpi.name}</h3>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-600">{kpi.current} / {kpi.target}</span>
                  <span className={`text-sm font-semibold text-${statusColor}-700`}>{percentage.toFixed(0)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                  <div 
                    className={`bg-${statusColor}-600 h-2 rounded-full`} 
                    style={{width: `${percentage}%`}}
                  ></div>
                </div>
                <div className="flex items-center gap-1">
                  {kpi.status === 'on-track' ? (
                    <Check className="w-4 h-4 text-green-600" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-orange-600" />
                  )}
                  <span className={`text-xs text-${statusColor}-700 font-medium`}>
                    Status: {statusText}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );

  // Screen: Reports
  const ReportsScreen = () => (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-green-700 text-white p-4 shadow-lg">
        <div className="flex items-center gap-3">
          <ArrowLeft className="w-6 h-6 cursor-pointer" onClick={() => setCurrentScreen('home')} />
          <h1 className="text-xl font-bold">My Reports</h1>
        </div>
      </div>

      <div className="p-4 space-y-3">
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="font-semibold text-gray-800">Weekly Report</h3>
              <p className="text-xs text-gray-500">Feb 3 - Feb 9, 2026</p>
            </div>
            <FileText className="w-8 h-8 text-blue-600" />
          </div>
          <div className="grid grid-cols-3 gap-2 mb-3">
            <div className="bg-blue-50 p-2 rounded text-center">
              <div className="font-bold text-blue-700">12</div>
              <div className="text-xs text-gray-600">Activities</div>
            </div>
            <div className="bg-green-50 p-2 rounded text-center">
              <div className="font-bold text-green-700">8</div>
              <div className="text-xs text-gray-600">Growers</div>
            </div>
            <div className="bg-orange-50 p-2 rounded text-center">
              <div className="font-bold text-orange-700">$245</div>
              <div className="text-xs text-gray-600">Expenses</div>
            </div>
          </div>
          <button className="w-full bg-blue-600 text-white py-2 rounded font-medium">
            Generate PDF
          </button>
        </div>

        <div className="bg-white p-4 rounded-lg shadow">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="font-semibold text-gray-800">Monthly Report</h3>
              <p className="text-xs text-gray-500">February 2026</p>
            </div>
            <FileText className="w-8 h-8 text-green-600" />
          </div>
          <div className="grid grid-cols-3 gap-2 mb-3">
            <div className="bg-blue-50 p-2 rounded text-center">
              <div className="font-bold text-blue-700">45</div>
              <div className="text-xs text-gray-600">Activities</div>
            </div>
            <div className="bg-green-50 p-2 rounded text-center">
              <div className="font-bold text-green-700">34</div>
              <div className="text-xs text-gray-600">Growers</div>
            </div>
            <div className="bg-orange-50 p-2 rounded text-center">
              <div className="font-bold text-orange-700">$1,245</div>
              <div className="text-xs text-gray-600">Expenses</div>
            </div>
          </div>
          <button className="w-full bg-green-600 text-white py-2 rounded font-medium">
            Generate PDF
          </button>
        </div>

        <div className="bg-white p-4 rounded-lg shadow">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="font-semibold text-gray-800">Quarterly Report</h3>
              <p className="text-xs text-gray-500">Q1 2026 (Jan - Mar)</p>
            </div>
            <FileText className="w-8 h-8 text-purple-600" />
          </div>
          <div className="grid grid-cols-3 gap-2 mb-3">
            <div className="bg-blue-50 p-2 rounded text-center">
              <div className="font-bold text-blue-700">120</div>
              <div className="text-xs text-gray-600">Activities</div>
            </div>
            <div className="bg-green-50 p-2 rounded text-center">
              <div className="font-bold text-green-700">85</div>
              <div className="text-xs text-gray-600">Growers</div>
            </div>
            <div className="bg-orange-50 p-2 rounded text-center">
              <div className="font-bold text-orange-700">$3,890</div>
              <div className="text-xs text-gray-600">Expenses</div>
            </div>
          </div>
          <button className="w-full bg-purple-600 text-white py-2 rounded font-medium">
            Generate PDF
          </button>
        </div>
      </div>
    </div>
  );

  // Handlers
  const handleSaveActivity = () => {
    if (!newActivity.description) {
      alert('Please add a description');
      return;
    }
    
    const activity = {
      id: String(activities.length + 1),
      category: newActivity.category,
      description: newActivity.description,
      date: newActivity.date,
      time: newActivity.time,
      location: newActivity.location,
      gps: newActivity.gps,
      photos: newActivity.photos,
      expenses: newActivity.expenses,
      synced: true
    };
    
    setActivities([activity, ...activities]);
    
    // Reset form
    setNewActivity({
      category: categories[0],
      description: '',
      date: new Date().toISOString().split('T')[0],
      time: new Date().toTimeString().slice(0, 5),
      location: 'Auto-detected',
      gps: { lat: -17.8252, lon: 31.0335 },
      photos: [],
      expenses: []
    });
    
    setCurrentScreen('home');
  };

  const handleAddExpense = () => {
    if (!newExpense.amount) {
      alert('Please enter an amount');
      return;
    }
    
    setNewActivity({
      ...newActivity,
      expenses: [...newActivity.expenses, {
        type: newExpense.type,
        amount: parseFloat(newExpense.amount),
        notes: newExpense.notes
      }]
    });
    
    setNewExpense({
      type: expenseTypes[0],
      amount: '',
      notes: ''
    });
    
    setCurrentScreen('new-activity');
  };

  // Render current screen
  return (
    <div className="max-w-md mx-auto bg-white shadow-2xl" style={{minHeight: '100vh'}}>
      {currentScreen === 'home' && <HomeScreen />}
      {currentScreen === 'new-activity' && <NewActivityScreen />}
      {currentScreen === 'add-expense' && <AddExpenseScreen />}
      {currentScreen === 'activities' && <ActivitiesScreen />}
      {currentScreen === 'kpis' && <KPIScreen />}
      {currentScreen === 'reports' && <ReportsScreen />}
    </div>
  );
}

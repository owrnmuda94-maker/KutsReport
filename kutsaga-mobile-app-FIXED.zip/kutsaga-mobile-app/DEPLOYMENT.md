# Deployment Instructions

## Option 1: Vercel (Recommended - Easiest)

### Steps:
1. Go to https://vercel.com
2. Sign up with GitHub, GitLab, or email
3. Click "Add New Project"
4. Choose "Upload" tab
5. Drag and drop the entire `kutsaga-mobile-app` folder
6. Click "Deploy"
7. Wait 1-2 minutes
8. Get your URL: `https://your-project.vercel.app`

### Automatic Deployment:
Vercel auto-detects Vite and builds automatically. No configuration needed!

### Custom Domain:
1. Go to Project Settings → Domains
2. Add your domain (e.g., fieldops.kutsaga.co.zw)
3. Update DNS records as shown
4. Done!

---

## Option 2: Netlify

### Steps:
1. First, build the project locally:
   ```bash
   npm install
   npm run build
   ```

2. Go to https://netlify.com
3. Sign up for free account
4. Click "Add new site" → "Deploy manually"
5. Drag and drop the `dist` folder
6. Get your URL: `https://your-site.netlify.app`

### Custom Domain:
1. Site Settings → Domain Management
2. Add custom domain
3. Follow DNS instructions

---

## Option 3: GitHub Pages

### Steps:
1. Create a GitHub account
2. Create new repository: `kutsaga-field-ops`
3. Upload the project files
4. Build locally:
   ```bash
   npm install
   npm run build
   ```

5. Install gh-pages:
   ```bash
   npm install --save-dev gh-pages
   ```

6. Add to package.json scripts:
   ```json
   "predeploy": "npm run build",
   "deploy": "gh-pages -d dist"
   ```

7. Deploy:
   ```bash
   npm run deploy
   ```

8. Enable GitHub Pages in repository settings
9. URL: `https://your-username.github.io/kutsaga-field-ops`

---

## Option 4: Your Own Server

### Requirements:
- Web server (Apache, Nginx, etc.)
- SSH access
- Domain name (optional)

### Steps:
1. Build the project:
   ```bash
   npm install
   npm run build
   ```

2. Upload `dist` folder contents to your server:
   ```bash
   scp -r dist/* user@your-server.com:/var/www/html/
   ```

3. Configure web server to serve the files

4. Access via your domain or IP address

### Apache Configuration:
```apache
<VirtualHost *:80>
    ServerName fieldops.kutsaga.co.zw
    DocumentRoot /var/www/html/kutsaga
    
    <Directory /var/www/html/kutsaga>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
        
        # PWA support
        RewriteEngine On
        RewriteBase /
        RewriteRule ^index\.html$ - [L]
        RewriteCond %{REQUEST_FILENAME} !-f
        RewriteCond %{REQUEST_FILENAME} !-d
        RewriteRule . /index.html [L]
    </Directory>
</VirtualHost>
```

### Nginx Configuration:
```nginx
server {
    listen 80;
    server_name fieldops.kutsaga.co.zw;
    root /var/www/html/kutsaga;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # Cache static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

---

## Option 5: Firebase Hosting

### Steps:
1. Install Firebase CLI:
   ```bash
   npm install -g firebase-tools
   ```

2. Login:
   ```bash
   firebase login
   ```

3. Initialize project:
   ```bash
   firebase init hosting
   ```
   - Select "Use existing project" or create new
   - Public directory: `dist`
   - Single-page app: `Yes`
   - Don't overwrite index.html

4. Build and deploy:
   ```bash
   npm run build
   firebase deploy
   ```

5. Get URL: `https://your-project.firebaseapp.com`

---

## Comparison

| Platform | Difficulty | Speed | Cost | Custom Domain | Auto-Deploy |
|----------|-----------|-------|------|---------------|-------------|
| **Vercel** | ⭐ Easy | ⚡ Fast | Free | ✅ Yes | ✅ Yes |
| Netlify | ⭐ Easy | ⚡ Fast | Free | ✅ Yes | ✅ Yes |
| GitHub Pages | ⭐⭐ Medium | ⚡ Fast | Free | ✅ Yes | ✅ Yes |
| Firebase | ⭐⭐ Medium | ⚡ Fast | Free | ✅ Yes | ✅ Yes |
| Own Server | ⭐⭐⭐ Hard | 🐌 Varies | Paid | ✅ Yes | ❌ No |

---

## Recommended Workflow

### For Development/Testing:
```bash
# Run locally
npm run dev
# Access on phone via network URL
```

### For Production:
```bash
# Build
npm run build

# Deploy to Vercel
# (Just drag and drop to Vercel dashboard)
```

### For Updates:
```bash
# Make changes to code
# Build again
npm run build

# Redeploy to same platform
# Users get updates automatically on refresh
```

---

## SSL/HTTPS

All mentioned platforms (Vercel, Netlify, GitHub Pages, Firebase) provide free SSL certificates automatically.

For your own server, use Let's Encrypt:
```bash
sudo apt install certbot python3-certbot-apache
sudo certbot --apache -d fieldops.kutsaga.co.zw
```

---

## Post-Deployment Checklist

After deploying:
- [ ] Test on iPhone Safari
- [ ] Add to Home Screen and verify
- [ ] Test offline functionality
- [ ] Check camera permissions
- [ ] Test GPS location
- [ ] Verify all screens work
- [ ] Test adding activities
- [ ] Check expense tracking
- [ ] Review KPI dashboard
- [ ] Generate sample reports
- [ ] Share URL with test users

---

## Next Steps

1. Choose deployment platform
2. Deploy the app
3. Test on iPhone
4. Share with team
5. Gather feedback
6. Iterate and improve

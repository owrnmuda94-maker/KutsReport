# 📱 iPhone Quick Start Guide
## Get Kutsaga Field Ops Running in 5 Minutes

---

## ⚡ FASTEST METHOD (No Technical Skills Required)

### What You'll Do:
1. Upload app to Vercel (free website hosting)
2. Open on your iPhone
3. Add to home screen
4. Start using!

---

## 📋 Step-by-Step Instructions

### PART 1: Deploy the App (On Your Computer)

#### Step 1: Go to Vercel
1. Open browser on your computer
2. Go to: **https://vercel.com**
3. Click **"Sign Up"** (top right)
4. Sign up with:
   - GitHub account (recommended), OR
   - GitLab account, OR
   - Email address
5. Verify your email if needed

#### Step 2: Upload the App
1. After logging in, click **"Add New..."** → **"Project"**
2. You'll see options to import from Git or upload files
3. Look for **"Browse"** or drag-and-drop area
4. Select the entire **`kutsaga-mobile-app`** folder from your downloads
5. Click **"Upload"**

#### Step 3: Deploy
1. Vercel will automatically detect it's a Vite project
2. Leave all settings as default
3. Click **"Deploy"**
4. Wait 1-2 minutes while it builds
5. You'll see: ✅ "Congratulations! Your project is deployed"

#### Step 4: Get Your URL
1. You'll see a URL like: `https://kutsaga-mobile-app-abc123.vercel.app`
2. Click on it to open and test
3. **Copy this URL** - you'll need it for your iPhone

---

### PART 2: Install on iPhone

#### Step 5: Open in Safari
1. Pick up your iPhone
2. Open **Safari** browser (the blue compass icon)
   - ⚠️ MUST use Safari, not Chrome
3. Type or paste your Vercel URL
4. The app will load in Safari

#### Step 6: Add to Home Screen
1. At the bottom of Safari, tap the **Share button**
   - It looks like a square with an arrow pointing up ⬆️
2. Scroll down the menu
3. Tap **"Add to Home Screen"**
   - Look for the icon with a plus sign +
4. You can edit the name:
   - Change to "Kutsaga" or "Field Ops" if you want
5. Tap **"Add"** (top right corner)

#### Step 7: Launch the App
1. Press home button or swipe up to exit Safari
2. Find the new **Kutsaga** icon on your home screen
   - It will look like a green app icon
3. Tap the icon
4. The app opens full-screen like a regular app! 🎉

---

## ✅ You're Done!

The app is now installed and ready to use.

### What You Can Do Now:
- ✓ Take it offline (works without internet)
- ✓ Log activities with photos
- ✓ Track expenses
- ✓ View KPI progress
- ✓ Generate reports

---

## 🎓 Using the App

### First Time Setup:
1. When you open the app, you'll see the home dashboard
2. Tap **"LOG NEW ACTIVITY"** (big green button)
3. Try logging a test activity:
   - Select a category
   - Tap camera to take photo (allow permission)
   - Write a description
   - Tap "Submit Activity"

### Main Features:
- **Home** - See your weekly summary
- **Log Activity** - Add new field work
- **My Activities** - View all logged activities
- **KPIs** - Check your progress
- **Reports** - Generate weekly/monthly reports

---

## 🔧 Troubleshooting

### "I can't find the Share button"
- Make sure you're using Safari (not Chrome)
- The share button is at the bottom center of Safari
- It's a square with an arrow pointing up

### "Add to Home Screen is greyed out"
- Update your iPhone to latest iOS
- Close and reopen Safari
- Try clearing Safari history

### "The app won't load"
- Check your internet connection
- Make sure the Vercel URL is correct
- Try refreshing the page

### "Camera permission not working"
- Go to iPhone Settings
- Scroll to Safari
- Make sure Camera is allowed

### "GPS location not working"
- Go to iPhone Settings
- Privacy & Security → Location Services
- Make sure Safari has permission

---

## 🔄 Updating the App

When you make changes to the app:

1. Go back to Vercel on your computer
2. Upload the new version
3. On your iPhone, open the app
4. Pull down to refresh
5. New version loads automatically!

No need to reinstall - updates happen instantly.

---

## 👥 Sharing with Team

To let others use the app:

1. Share your Vercel URL with them:
   - `https://kutsaga-mobile-app-abc123.vercel.app`
2. They follow the same Steps 5-7 above
3. Each person adds it to their own iPhone
4. Everyone uses the same app!

---

## 💡 Pro Tips

### Make it Easier to Find:
- Put the app icon in your dock
- Create a folder with other work apps
- Name it something short like "Kutsaga"

### Use Offline:
- Open the app once while online
- After that, it works without internet
- Photos and data sync when you're back online

### Save Battery:
- Close other apps when using camera
- Lower screen brightness in the field
- The app is optimized for battery life

---

## 📞 Need Help?

### Can't Deploy to Vercel?
- Try Netlify instead: https://netlify.com
- Same process: Sign up → Upload → Deploy

### Want to Use Your Own Domain?
- In Vercel, go to Project Settings
- Click "Domains"
- Add: fieldops.kutsaga.co.zw
- Follow DNS instructions

### Technical Issues?
- Check INSTALLATION_GUIDE.md for detailed help
- See TROUBLESHOOTING section
- Contact your IT support

---

## 🎯 Next Steps

After installing:

1. ✅ Test logging an activity
2. ✅ Add a photo
3. ✅ Record an expense
4. ✅ Check KPI dashboard
5. ✅ Generate a report
6. ✅ Share with 2-3 colleagues for testing
7. ✅ Gather feedback
8. ✅ Roll out to full team

---

## ⏱️ Time Required

- Deploying to Vercel: **3 minutes**
- Adding to iPhone: **2 minutes**
- Testing the app: **5 minutes**

**Total: About 10 minutes from start to finish!**

---

## 🌟 Remember

- The app works offline after first load
- No App Store needed
- Free to use and deploy
- Easy to update
- Secure and private

**You're all set! Start logging your field activities! 🚀**
